"""
Watson OSINT Tool
================

Un outil puissant pour rechercher des noms d'utilisateur sur de multiples plateformes.
Développé par margoul1.
"""

__version__ = "0.1.0"
__author__ = "margoul1"

from watson.core.watson import main 