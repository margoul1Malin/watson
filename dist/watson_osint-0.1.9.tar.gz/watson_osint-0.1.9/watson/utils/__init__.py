# watson.utils module
# Modules utilitaires pour le package Watson 