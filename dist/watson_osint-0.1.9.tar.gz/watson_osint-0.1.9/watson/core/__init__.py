"""
Module core de Watson OSINT
==========================

Ce module contient les fonctionnalités principales de Watson.
"""

from .watson import main 